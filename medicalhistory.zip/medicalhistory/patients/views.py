
from django.shortcuts import render


def patients_view(request):
    return render(request, 'listing.html')

# Create your views here.
